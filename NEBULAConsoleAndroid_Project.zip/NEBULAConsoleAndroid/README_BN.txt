NEBULA X CONSOLE - Android project

এই ZIP-এ Android WebView অ্যাপের সোর্স প্রজেক্ট আছে। HTML প্যানেলটি অ্যাপের ভিতরে চলবে।

APK বানাতে:
1. Android Studio-তে এই ZIP extract করে প্রজেক্টটি Open করুন।
2. Gradle sync শেষ হতে দিন (ইন্টারনেট লাগতে পারে)।
3. Build > Build APK(s) চাপুন।
4. APK সাধারণত app/build/outputs/apk/debug/app-debug.apk-তে তৈরি হবে।

গুরুত্বপূর্ণ:
এটি একটি slider demo panel। স্লাইডারের মান অ্যাপের UI-তে বদলায়, কিন্তু এটি নিজে থেকে Free Fire-এর গেম সেটিংস বদলায় না বা অটো-হেডশট দেয় না।
